<?php
/*
 * Plugin Name: Noupia Pay
 * Description: Accept instant   online payments on your WooCommerce website.
 * Author: Noupia Limited
 * Author URI: https://noupia.com
 * Text Domain: noupia
 * Version: 1.0
 * License: GNU Public License
 * License URI: https://opensource.org/licenses/gpl-2.0.php
 */

if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) return;


ini_set('max_execution_time', 2400);

/*
 * This action hook registers our PHP class as a WooCommerce payment gateway
 */
add_filter( 'woocommerce_payment_gateways', 'noupia_add_gateway_class' );
function noupia_add_gateway_class( $gateways ) {
	$gateways[] = 'WC_Noupia_Pay_Gateway'; // your class name is here
	return $gateways;
}


add_filter( 'http_request_timeout', 'wp9838c_timeout_extend' );

function wp9838c_timeout_extend( $time )
{
    // Default timeout is 5
    return 2400;
}

/*
 * The class itself, please note that it is inside plugins_loaded action hook
 */
add_action( 'plugins_loaded', 'misha_init_gateway_class' );
function misha_init_gateway_class() {

	class WC_Noupia_Pay_Gateway extends WC_Payment_Gateway {

 		/**
 		 * Class constructor, more about it in Step 3
 		 */
 		public function __construct() {

            $this->id = 'noupiapay'; // payment gateway ID
            $this->icon = plugins_url('noupia-pay-logo.png', __FILE__); // payment gateway icon
            $this->has_fields = true; // for custom credit card form
            $this->title = __( 'Noupia Pay', 'text-domain' ); // vertical tab title
            $this->method_title = __( 'Noupia Pay', 'text-domain' ); // payment method name
            $this->method_description = __( 'Noupia Pay or Mobile Money Payments on your website.', 'text-domain' ); // payment method description

            $this->supports = array( 
                'default_credit_card_form',
                'products'
            );

            // load backend options fields
            $this->init_form_fields();

            // load the settings.
            $this->init_settings();
            $this->title = $this->get_option( 'title' );
            $this->description = $this->get_option( 'description' );
            $this->enabled = $this->get_option( 'enabled' );
            $this->test_mode = 'yes' === $this->get_option( 'test_mode' );
            $this->private_key = $this->test_mode ? $this->get_option( 'test_private_key' ) : $this->get_option( 'private_key' );
            $this->publish_key = $this->test_mode ? $this->get_option( 'test_publish_key' ) : $this->get_option( 'publish_key' );

            // Action hook to saves the settings
            if(is_admin()) {
                add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
            }

            // Action hook to load custom JavaScript
            add_action( 'wp_enqueue_scripts', array( $this, 'payment_gateway_scripts' ) );
 		}

		/**
 		 * Plugin options, we deal with it in Step 3 too
 		 */
        public function init_form_fields(){

            $this->form_fields = array(
                'enabled' => array(
                    'title'       => __( 'Enable/Disable', 'text-domain' ),
                    'label'       => __( 'Enable Noupia Pay', 'text-domain' ),
                    'type'        => 'checkbox',
                    'description' => __( 'This enables the Noupia Pay gateway which allows you to accept payments through Noupia Pay or Mobile Money in your WooCommerce store.', 'text-domain' ),
                    'default'     => 'no',
                    'desc_tip'    => true
                ),
                'title' => array(
                    'title'       => __( 'Title', 'text-domain'),
                    'type'        => 'text',
                    'description' => __( 'This controls the title which the user sees during checkout.', 'text-domain' ),
                    'default'     => __( 'Mobile Money - Africa', 'text-domain' ),
                    'desc_tip'    => true,
                ),
                'method' => array(
                    'title'       => __( 'Method', 'text-domain'),
                    'type'        => 'select',
                    'options'     => array(
                        'mobilemoney' => 'Mobile Money (mobilemoney) ONLY',
                        'noupia' => 'Noupia Pay (noupia) ONLY',
                        'both' => 'Both methods (noupia & mobilemoney)'
                    ),
                    'description' => __( 'This defines the method user will pay in mobilemoney or noupia.', 'text-domain' ),
                    'default'     => __( 'both', 'text-domain' ),
                    'desc_tip'    => false,
                ),
                'description' => array(
                    'title'       => __( 'Description', 'text-domain' ),
                    'type'        => 'textarea',
                    'description' => __( 'This controls the description which the user sees during checkout.', 'text-domain' ),
                    'default'     => __( 'Pay with Mobile Money - via Noupia Pay.', 'text-domain' ),
                ),
                'publish_key' => array(
                    'title'       => __( 'Noupia Developer Key', 'text-domain' ),
                    'type'        => 'text',
                    'placeholder' => 'PASTE_YOUR_DEVELOPER_KEY',
                ),
                'private_key' => array(
                    'title'       => __( 'Noupia Pay Subscription Key', 'text-domain' ),
                    'type'        => 'password',
                    'placeholder' => 'PASTE_YOUR_NOUPIA_PAY_SUBSCRIPTION_KEY',
                )
            );
        }

		/**
		 * You will need it if you want your custom credit card form, Step 4 is about it
		 */
		public function payment_fields() {

            if ( $this->description ) {
                if ( $this->test_mode ) {
                    $this->description .= ' Test mode is enabled. You can use the dummy credit card numbers to test it.';
                }
                echo wpautop( wp_kses_post( $this->description ) );
            }
            
            ?>
        
            <fieldset id="wc-<?php echo esc_attr( $this->id ); ?>-cc-form" class="wc-credit-card-form wc-payment-form" style="background:transparent;">
                <?php do_action( 'woocommerce_credit_card_form_start', $this->id ); ?> 
                <?php if ( $this->get_option( 'method' ) == 'both' ): ?>
                <div class="form-row form-row-wide">
                    <label>Payment Method <span class="required">*</span></label>
                    <select name="noupiapay_method" required class="input-text">
                        <option value="" disabled selected>Please select</option>
                        <option value="mobilemoney">Mobile Money</option>
                        <option value="noupia">Noupia Pay</option>
                    </select>
                </div>
                <?php else: ?>
                <div class="form-row form-row-wide">
                    <input name="noupiapay_method" type="hidden" 
                    value="<?php print $this->get_option( 'method' ) ?>">
                </div>
                <?php endif; ?>
                <div class="form-row form-row-wide">
                    <label>Account Phone Number <span class="required">*</span></label>
                    <input name="noupiapay_accno" id="noupiapay_accno" type="number" autocomplete="off" class="input-text">
                </div>
                <div class="clear"></div>
                <?php do_action( 'woocommerce_credit_card_form_end', $this->id ); ?> 
                <div class="clear"></div> 
            </fieldset>
        
            <?php
         
        }

		/*
		 * Custom CSS and JS, in most cases required only when you decided to go with a custom credit card form
		 */
        public function payment_gateway_scripts() {

            // process a token only on cart/checkout pages
            if ( ! is_cart() && ! is_checkout() && ! isset( $_GET['pay_for_order'] ) ) {
                return;
            }
        
            // stop enqueue JS if payment gateway is disabled
            if ( 'no' === $this->enabled ) {
                return;
            }
        
            // stop enqueue JS if API keys are not set
            if ( empty( $this->private_key ) || empty( $this->publishable_key ) ) {
                return;
            }
        
            // stop enqueue JS if test mode is enabled
            if ( ! $this->test_mode ) {
                return;
            }
        
            // stop enqueue JS if site without SSL
            if ( ! is_ssl() ) {
                //return;
            }
        
            // payment processor JS that allows to get a token
            wp_enqueue_script( 'noupiapay_js', 'https://www.example.com/api/get-token.js' );
        
            // custom JS that works with get-token.js
            wp_register_script( 'woocommerce_pay_noupiapay', plugins_url( 'token-script.js', __FILE__ ), array( 'jquery', 'noupiapay_js' ) );
        
            // use public key to get token
            wp_localize_script( 'woocommerce_pay_noupiapay', 'noupiapay_params', array(
                'publishKey' => $this->publish_key
            ) );
        
            wp_enqueue_script( 'woocommerce_pay_noupiapay' );
        
        }

		/*
 		 * Fields validation, more in Step 5
		 */
		public function validate_fields(){

            if( empty( $_POST[ 'billing_first_name' ]) ) {
                wc_add_notice(  'First name is required!', 'error' );
                return false;
            }
            if( empty( $_POST[ 'billing_email' ]) ) {
                wc_add_notice(  'Email is required!', 'error' );
                return false;
            }
            if( empty( $_POST[ 'noupiapay_accno' ]) ) {
                wc_add_notice(  'Account Phone Number is required!', 'error' );
                return false;
            }
            if( empty( $_POST[ 'noupiapay_method' ]) ) {
                wc_add_notice(  'Please, select a payment method.', 'error' );
                return false;
            }
            
            return true;
         
        }

		/*
		 * We're processing the payments here, everything about it is in Step 5
		 */
		public function process_payment( $order_id ) {

            global $woocommerce;
   
            // get order details
            $order = new WC_Order($order_id); // wc_get_order( $order_id ); 
            

            $order_data = $order->get_data(); // The Order data

            //$order_id = $order_data['id'];   

            $order_amount = $order->get_total();
         
            // Array with arguments for API interaction
            $args = [
                'method' => 'POST',
                'headers' => [
                    'Noupia-Api-Signature' => 'np-live',
                    'Noupia-Api-Key' => $this->publish_key,
                    'Noupia-Product-Key' => $this->private_key,
                    'Content-Type' => 'application/json'
                ],
                'body' => json_encode([
                    'operation' => 'initiate',
                    'method' => $_POST['noupiapay_method'], // $this->get_option( 'method' ),
                    'reference' => sprintf('WOOCOMMERCE%s %s %s%s', $order_id, $_POST[ 'billing_last_name' ], $order_amount, $order_data['currency']),
                    'phone' => $_POST[ 'noupiapay_accno' ],
                    'amount' => (int) $order_amount,
                    'woocommerce' => true,
                    'currency' => strtoupper($order_data['currency'])
                ]),
                'timeout' => 2400,
            ];
            
            $response = wp_remote_post( 'https://api.noupia.com/pay', $args );
         
            if( !is_wp_error( $response ) ) {
         
                $body = json_decode( $response['body'], true );
         
                // it could be different depending on your payment processor
                if ( $body['response'] == 'success' ) {

                    // empty cart
                    $woocommerce->cart->empty_cart();

                    // we received the payment
                    $order->payment_complete();
                      
                    if ($this->get_option( 'method' ) == 'noupia') {
                        $order->add_order_note( sprintf('Awaiting payment via Noupia Pay %s - Tap "Pay" button to complete payment.', $_POST[ 'noupiapay_accno' ]), true );
                    } 
                    else if($this->get_option( 'method' ) == 'mobilemoney') {
                        $order->add_order_note( sprintf('Awaiting payment. Dial %s - %s', $body['data']['channel_ussd'], $body['data']['channel_name']), true );
                    }

                    $transaction = $body['data']['transaction'];
                    $args = [
                        'method' => 'POST',
                        'headers' => [
                            'Noupia-Api-Signature' => 'np-live',
                            'Noupia-Api-Key' => $this->publish_key,
                            'Noupia-Product-Key' => $this->private_key,
                            'Content-Type' => 'application/json'
                        ],
                        'body' => json_encode([
                            'operation' => 'verify', 
                            'transaction' => $transaction, 
                        ]),
                        'timeout' => 120,
                    ];
                    
                    while (true) {
                        sleep(8);
                        $response2 = wp_remote_post( 'https://api.noupia.com/pay', $args );
                        if( !is_wp_error( $response2 ) ) {
                            $body2 = json_decode( $response2['body'], true );
                            if ( $body2['response'] == 'success' and isset($body2['data'])) { 
        
                                if ( $body2['data']['status'] == 'successful' ) {
                                     
                                    $order->reduce_order_stock();  
                                    $order->add_order_note( 'Hey, your order is paid! Thank you!', true );
                                    $order->add_order_note( 'This private note shows only on order edit page', false ); 
                                    $order->update_status('completed');
                                    // redirect to the thank you page
                                    return array(
                                        'result' => 'success',
                                        'redirect' => $this->get_return_url( $order )
                                    );
                                    break;
                                }
                                else if ( $body2['data']['status'] == 'failed') {
                        
                                    $order->add_order_note( 'Oops, your payment failed', true );
                                    $order->add_order_note( 'Sorry, but you order has failed! Kindly try again.', false );
                                    $order->update_status('failed');
                                    // redirect to the failed page
                                    return array(
                                        'result' => 'failed',
                                        'redirect' => $this->get_return_url( $order )
                                    );
                                    break;
                                }
                                else if ( $body2['data']['status'] == 'cancelled' ) {
                        
                                    $order->add_order_note( 'Oops, your payment cancelled', true );
                                    $order->add_order_note( 'Sorry, but you order was cancelled! Kindly try again.', false );
                                    $order->update_status('cancelled');
                                    // redirect to the failed page
                                    return array(
                                        'result' => 'cancelled',
                                        'redirect' => $this->get_return_url( $order )
                                    );
                                    break;
                                }
                                else{
                                    // Payment still pending...
                                    continue;
                                }
                            }
                            else{
                                // Something wrong with API call
                                wc_add_notice(  'Check status error. '. $body['message'], 'error' );
                                return;
                            }
                            //sleep(3);
                        } 
                        else {
                            wc_add_notice(  'Status check error. '.json_encode($response2), 'error' );
                            return;
                        }
                    }
         
                } else {
                    wc_add_notice(  'Payment error. '. $body['message'], 'error' );
                    return;
                }
         
            } else {
                wc_add_notice(  'Connection error.', 'error' );
                return;
            }
        }

        /*
		 * In case you need a webhook, like PayPal IPN etc
		 */
		public function webhook() {

            $order = wc_get_order( $_GET['id'] );
            $order->payment_complete();
            $order->reduce_order_stock();
        
            update_option('webhook_debug', $_GET);
        }

 	}
}